# ReadME

### Kommandon i kod
alt + pilar (upp | ner ) för att flytta rad ni står på upp | ner